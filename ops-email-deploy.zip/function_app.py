import os
import logging
from datetime import date, timedelta

import azure.functions as func

from sharepoint_client import (
    get_access_token,
    get_site_id,
    get_list_id,
    get_shifts_for_date,
    get_mtd_stars,
    download_file,
    send_email_graph,
    _fetch_all_items_for_date_range,
    COL_VENUE,
    COL_STAR,
    _normalize_shift,
)
from config_reader import read_venue_configs
from email_builder import build_email_html
from collections import Counter

app = func.FunctionApp()


@app.timer_trigger(schedule="0 0 5 * * *", arg_name="timer", run_on_startup=False)
def ops_email_timer(timer: func.TimerRequest) -> None:
    logging.info("Operations email function triggered")

    today = date.today()
    query_date = today - timedelta(days=1)  # query yesterday's shifts

    try:
        token = get_access_token()
        site_id = get_site_id(token)
        list_id = get_list_id(token, site_id)

        config_path = os.environ.get("CONFIG_FILE_PATH", "OpsEmailConfig.xlsx")
        excel_bytes = download_file(token, site_id, config_path)
        venue_configs = read_venue_configs(excel_bytes)

        # Fetch all items for the day in one call (avoids 73 separate API calls)
        date_str = query_date.strftime("%Y-%m-%dT00:00:00Z")
        date_end = query_date.strftime("%Y-%m-%dT23:59:59Z")
        all_day_items = _fetch_all_items_for_date_range(token, site_id, list_id, date_str, date_end)
        logging.info(f"Fetched {len(all_day_items)} shift items for {query_date}")

        # Fetch all MTD items in one call
        month_start = query_date.replace(day=1).strftime("%Y-%m-%dT00:00:00Z")
        all_mtd_items = _fetch_all_items_for_date_range(token, site_id, list_id, month_start, date_end)
        logging.info(f"Fetched {len(all_mtd_items)} MTD items for month")

        for config in venue_configs:
            venue = config["venue"]
            sender = config["sender_email"]
            recipients = config["recipients"]

            if not recipients:
                logging.warning(f"No recipients for {venue}, skipping")
                continue

            # Filter shifts for this venue from pre-fetched data
            venue_shifts = [
                _normalize_shift(item["fields"])
                for item in all_day_items
                if item["fields"].get(COL_VENUE, "").strip() == venue
            ]

            # Calculate MTD stars for this venue from pre-fetched data
            star_names = []
            for item in all_mtd_items:
                if item["fields"].get(COL_VENUE, "").strip() != venue:
                    continue
                star = item["fields"].get(COL_STAR, "").strip()
                if star:
                    star_names.append(star)

            counts = Counter(star_names)
            ranked = counts.most_common(3)
            medals = ["Gold medal", "Silver", "Bronze"]
            places = ["1st", "2nd", "3rd"]
            champions = []
            for i, (name, count) in enumerate(ranked):
                champions.append({
                    "medal": medals[i],
                    "place": places[i],
                    "name": name,
                    "stars": count,
                })

            html = build_email_html(venue, query_date, champions, venue_shifts)
            subject = f"{venue} - Operations Update {query_date.strftime('%d/%m/%Y')}"

            send_email_graph(token, sender, recipients, subject, html)
            logging.info(f"Sent ops email for {venue} ({len(venue_shifts)} shifts)")

    except Exception:
        logging.exception("Operations email function failed")
        raise
